import numpy as np
from datetime import datetime

def calculer_ema(prix, periode):
    if len(prix) < periode + 1:
        return None
    a = 2 / (periode + 1)
    ema = [float(prix[0])]
    for i in range(1, len(prix)):
        ema.append(float(prix[i]) * a + ema[-1] * (1 - a))
    return ema[-1]

def calculer_toute_ema(prix, periode):
    if len(prix) < periode + 1:
        return []
    a = 2 / (periode + 1)
    ema = [float(prix[0])]
    for i in range(1, len(prix)):
        ema.append(float(prix[i]) * a + ema[-1] * (1 - a))
    return ema

def calculer_rsi(prix, periode=14):
    if len(prix) < periode + 1:
        return 50
    cls = np.array(prix, dtype=float)
    deltas = np.diff(cls)
    gains = np.where(deltas > 0, deltas, 0)
    pertes = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains[-periode:])
    avg_loss = np.mean(pertes[-periode:])
    if avg_loss == 0:
        return 100
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def trouver_swings(hauts, bas, recul=2):
    ha = np.array(hauts, dtype=float)
    ba = np.array(bas, dtype=float)
    n = len(ha)
    swings = []
    for i in range(recul, n - recul):
        if all(ha[i] > ha[i - j] for j in range(1, recul + 1)) and \
           all(ha[i] > ha[i + j] for j in range(1, recul + 1)):
            swings.append({"type": "HIGH", "index": i, "price": float(ha[i])})
        if all(ba[i] < ba[i - j] for j in range(1, recul + 1)) and \
           all(ba[i] < ba[i + j] for j in range(1, recul + 1)):
            swings.append({"type": "LOW", "index": i, "price": float(ba[i])})
    return swings

def pente_ema(prix, periode):
    emas = calculer_toute_ema(prix, periode)
    if len(emas) < 5:
        return 0
    return emas[-1] - emas[-5]

def est_engulfing_bullish(ouvr, clot):
    if len(ouvr) < 3 or len(clot) < 3:
        return False
    p1_ouv = float(ouvr[-3])
    p1_clot = float(clot[-3])
    p2_ouv = float(ouvr[-2])
    p2_clot = float(clot[-2])
    p3_ouv = float(ouvr[-1])
    p3_clot = float(clot[-1])
    if p1_clot < p1_ouv:
        pass
    else:
        return False
    if p3_clot > p3_ouv and p3_ouv < p2_clot and p3_clot > p2_ouv:
        return True
    return False

def est_engulfing_bearish(ouvr, clot):
    if len(ouvr) < 3 or len(clot) < 3:
        return False
    p1_ouv = float(ouvr[-3])
    p1_clot = float(clot[-3])
    p2_ouv = float(ouvr[-2])
    p2_clot = float(clot[-2])
    p3_ouv = float(ouvr[-1])
    p3_clot = float(clot[-1])
    if p1_clot > p1_ouv:
        pass
    else:
        return False
    if p3_clot < p3_ouv and p3_ouv < p2_clot and p3_clot < p2_ouv:
        return True
    return False

def est_marteau(ouvr, haut, bas, clot):
    corps = abs(float(clot[-1]) - float(ouvr[-1]))
    ombre_b = float(ouvr[-1]) - float(bas[-1]) if float(clot[-1]) > float(ouvr[-1]) else float(clot[-1]) - float(bas[-1])
    ombre_h = float(haut[-1]) - float(ouvr[-1]) if float(clot[-1]) > float(ouvr[-1]) else float(haut[-1]) - float(clot[-1])
    if corps == 0:
        return False
    return ombre_b >= corps * 2 and ombre_h <= corps * 0.3

def est_etoile_filante(ouvr, haut, bas, clot):
    corps = abs(float(clot[-1]) - float(ouvr[-1]))
    ombre_h = float(haut[-1]) - max(float(ouvr[-1]), float(clot[-1]))
    ombre_b = min(float(ouvr[-1]), float(clot[-1])) - float(bas[-1])
    if corps == 0:
        return False
    return ombre_h >= corps * 2 and ombre_b <= corps * 0.3

def analyser_marche(ouvr, hauts, bas, clot):
    n = len(clot)
    if n < 50:
        px = float(clot[-1]) if clot else 0
        return {"signal": "ATTENTE", "entry": px, "reason": "besoin de 50+ bougies pour EMA"}

    prix = float(clot[-1])
    ouvr_arr = [float(x) for x in ouvr]
    haut_arr = [float(x) for x in hauts]
    bas_arr = [float(x) for x in bas]
    clot_arr = [float(x) for x in clot]

    ema50 = calculer_toute_ema(clot_arr, 50)
    ema200 = calculer_toute_ema(clot_arr, 200) if len(clot_arr) >= 201 else None

    if len(ema50) < 5:
        return {"signal": "ATTENTE", "entry": prix, "reason": "pas assez de donnees pour EMA 50"}

    ema50_actuel = ema50[-1]
    pente50 = pente_ema(clot_arr, 50)
    rsi = calculer_rsi(clot_arr, 14)
    swings = trouver_swings(haut_arr, bas_arr)

    dernier_haut = None
    dernier_bas = None
    if swings:
        hs = [s for s in swings if s["type"] == "HIGH"]
        bs = [s for s in swings if s["type"] == "LOW"]
        if hs:
            dernier_haut = max(s["price"] for s in hs[-5:])
        if bs:
            dernier_bas = min(s["price"] for s in bs[-5:])

    lignes = []
    lignes.append("=== TIER 1: FILTRE DE LIQUIDITE ===")
    lignes.append(f"Prix: {prix:.2f}")
    if dernier_haut:
        lignes.append(f"Structure haute: {dernier_haut:.2f}")
    if dernier_bas:
        lignes.append(f"Structure basse: {dernier_bas:.2f}")
    lignes.append(f"RSI 14: {rsi:.1f}")

    lignes.append("")
    lignes.append("=== TIER 2: REGIME HTF (EMA 50/200) ===")
    lignes.append(f"EMA 50: {ema50_actuel:.2f}")
    if ema200:
        lignes.append(f"EMA 200: {ema200[-1]:.2f}")
    lignes.append(f"Pente EMA 50 (5 bougies): {pente50:.4f}")

    tendance = "NEUTRE"
    alerte_ema = ""
    if ema200:
        if prix > ema50_actuel > ema200[-1] and pente50 > 0:
            tendance = "HAUSSIER"
            alerte_ema = "Prix > EMA 50 > EMA 200, pente positive"
        elif prix < ema50_actuel < ema200[-1] and pente50 < 0:
            tendance = "BAISSIER"
            alerte_ema = "Prix < EMA 50 < EMA 200, pente negative"
        elif prix > ema200[-1] and prix < ema50_actuel:
            tendance = "PULLBACK_HAUSSIER"
            alerte_ema = "Prix entre EMA 200 et EMA 50 (pullback haussier)"
        elif prix < ema200[-1] and prix > ema50_actuel:
            tendance = "PULLBACK_BAISSIER"
            alerte_ema = "Prix entre EMA 200 et EMA 50 (pullback baissier)"
        else:
            tendance = "RANGEMENT"
            alerte_ema = "Structure non claire - a eviter"
    else:
        if prix > ema50_actuel and pente50 > 0:
            tendance = "HAUSSIER"
            alerte_ema = "Prix > EMA 50, pente positive"
        elif prix < ema50_actuel and pente50 < 0:
            tendance = "BAISSIER"
            alerte_ema = "Prix < EMA 50, pente negative"
        else:
            tendance = "RANGEMENT"
            alerte_ema = "Structure non claire - a eviter"

    lignes.append(f"Regime: {tendance} ({alerte_ema})")

    lignes.append("")
    lignes.append("=== TIER 3: EXECUTION LTF ===")
    dans_pullback = False
    dans_zone_ema = False

    if ema200:
        zone_inf = min(ema200[-1], ema50_actuel)
        zone_sup = max(ema200[-1], ema50_actuel)
        dans_zone_ema = zone_inf <= prix <= zone_sup
        lignes.append(f"Zone EMA: {zone_inf:.2f} - {zone_sup:.2f}")
        lignes.append(f"Prix dans zone EMA: {'OUI' if dans_zone_ema else 'NON'}")

    sweep = None
    if tendance in ("HAUSSIER", "PULLBACK_HAUSSIER") and bs:
        plus_bas = min(s["price"] for s in bs[-3:])
        if prix < plus_bas * 1.005 and prix >= plus_bas * 0.99:
            sweep = {"type": "SSL_SWEEP", "level": plus_bas, "wick": plus_bas}
        elif bs and ema50_actuel:
            bas_ema50 = ema50_actuel
            for b in reversed(bs[-4:]):
                if b["price"] < ema50_actuel:
                    bas_ema50 = b["price"]
                    break
            if prix < bas_ema50 * 1.005 and prix >= bas_ema50 * 0.99:
                sweep = {"type": "SSL_SWEEP", "level": bas_ema50, "wick": bas_ema50}

    if tendance in ("BAISSIER", "PULLBACK_BAISSIER") and hs:
        plus_haut = max(s["price"] for s in hs[-3:])
        if prix > plus_haut * 0.995 and prix <= plus_haut * 1.01:
            sweep = {"type": "BSL_SWEEP", "level": plus_haut, "wick": plus_haut}
        elif hs and ema50_actuel:
            haut_ema50 = ema50_actuel
            for h in reversed(hs[-4:]):
                if h["price"] > ema50_actuel:
                    haut_ema50 = h["price"]
                    break
            if prix > haut_ema50 * 0.995 and prix <= haut_ema50 * 1.01:
                sweep = {"type": "BSL_SWEEP", "level": haut_ema50, "wick": haut_ema50}

    if sweep:
        lignes.append(f"Liquidite sweep: {sweep['type']} @ {sweep['level']:.2f}")
    else:
        lignes.append("Liquidite sweep: AUCUN")

    if rsi <= 35:
        lignes.append(f"RSI {rsi:.1f} -> surachat/survendu: SURVENDU")
    elif rsi >= 65:
        lignes.append(f"RSI {rsi:.1f} -> surachat/survendu: SURACHAT")
    else:
        lignes.append(f"RSI {rsi:.1f} -> neutre")

    engl_bull = est_engulfing_bullish(ouvr_arr, clot_arr)
    engl_bear = est_engulfing_bearish(ouvr_arr, clot_arr)
    marteau = est_marteau(ouvr_arr, haut_arr, bas_arr, clot_arr)
    etoile = est_etoile_filante(ouvr_arr, haut_arr, bas_arr, clot_arr)

    bougie_achat = engl_bull or marteau
    bougie_vente = engl_bear or etoile

    lignes.append(f"Bougie: {'Engulfing Bull' if engl_bull else ''}{'Marteau' if marteau else ''}{'Engulfing Bear' if engl_bear else ''}{'Etoile Filante' if etoile else 'AUCUNE' if not (engl_bull or engl_bear or marteau or etoile) else ''}")

    score_a = 0
    score_v = 0
    motifs_conf = []

    if tendance in ("HAUSSIER", "PULLBACK_HAUSSIER"):
        if prix > ema50_actuel:
            score_a += 3
            motifs_conf.append(f"Tendance haussiere (prix > EMA 50, pente {pente50:.4f})")
    elif tendance in ("BAISSIER", "PULLBACK_BAISSIER"):
        if prix < ema50_actuel:
            score_v += 3
            motifs_conf.append(f"Tendance baissiere (prix < EMA 50, pente {pente50:.4f})")

    if ema200:
        if dans_zone_ema:
            if tendance in ("HAUSSIER", "PULLBACK_HAUSSIER"):
                score_a += 2
                motifs_conf.append("Prix dans zone EMA (pullback vers 50/200)")
            elif tendance in ("BAISSIER", "PULLBACK_BAISSIER"):
                score_v += 2
                motifs_conf.append("Prix dans zone EMA (pullback vers 50/200)")

    if sweep:
        if sweep["type"] == "SSL_SWEEP" and tendance in ("HAUSSIER", "PULLBACK_HAUSSIER"):
            score_a += 3
            motifs_conf.append(f"Sweep SSL confirme (liquidite chasse sous {sweep['level']:.2f})")
        elif sweep["type"] == "BSL_SWEEP" and tendance in ("BAISSIER", "PULLBACK_BAISSIER"):
            score_v += 3
            motifs_conf.append(f"Sweep BSL confirme (liquidite chasse au-dessus {sweep['level']:.2f})")

    if rsi <= 35 and tendance in ("HAUSSIER", "PULLBACK_HAUSSIER"):
        score_a += 2
        motifs_conf.append(f"RSI survendu ({rsi:.1f}) dans tendance haussiere")
    elif rsi >= 65 and tendance in ("BAISSIER", "PULLBACK_BAISSIER"):
        score_v += 2
        motifs_conf.append(f"RSI surachat ({rsi:.1f}) dans tendance baissiere")

    if bougie_achat and tendance in ("HAUSSIER", "PULLBACK_HAUSSIER"):
        score_a += 2
        motifs_conf.append("Bougie de confirmation haussiere")
    if bougie_vente and tendance in ("BAISSIER", "PULLBACK_BAISSIER"):
        score_v += 2
        motifs_conf.append("Bougie de confirmation baissiere")

    lignes.append("")
    lignes.append("=== CONFLUENCE CHECKLIST ===")
    for m in motifs_conf:
        lignes.append(f"  [OK] {m}")
    lignes.append(f"  Score Achat: {score_a} / Score Vente: {score_v}")

    setup = {}
    raison = "\n".join(lignes)

    signal = "ATTENTE"

    if score_a >= 7 and score_a >= score_v + 2:
        signal = "ACHAT"
        sl_base = sweep["wick"] if sweep and sweep["wick"] else (dernier_bas if dernier_bas else prix * 0.99)
        sl = sl_base - (sl_base * 0.003) if sl_base < prix else sl_base
        sl = round(sl, 2)
        risque = prix - sl
        if risque > 0:
            tp1 = round(prix + risque * 2, 2)
            tp2 = round(prix + risque * 3, 2)
        else:
            tp1 = round(prix * 1.03, 2)
            tp2 = round(prix * 1.05, 2)
        if dernier_haut and tp1 < dernier_haut:
            tp1 = round(dernier_haut, 2)
        rr = round((tp1 - prix) / (prix - sl), 1) if (prix - sl) > 0 else 0
        setup = {"signal": signal, "entry": prix, "sl": sl, "tp1": tp1, "tp2": tp2, "rr": rr, "reason": raison}

    elif score_v >= 7 and score_v >= score_a + 2:
        signal = "VENTE"
        sl_base = sweep["wick"] if sweep and sweep["wick"] else (dernier_haut if dernier_haut else prix * 1.01)
        sl = sl_base + (sl_base * 0.003) if sl_base > prix else sl_base
        sl = round(sl, 2)
        risque = sl - prix
        if risque > 0:
            tp1 = round(prix - risque * 2, 2)
            tp2 = round(prix - risque * 3, 2)
        else:
            tp1 = round(prix * 0.97, 2)
            tp2 = round(prix * 0.95, 2)
        if dernier_bas and tp1 > dernier_bas:
            tp1 = round(dernier_bas, 2)
        rr = round((prix - tp1) / (sl - prix), 1) if (sl - prix) > 0 else 0
        setup = {"signal": signal, "entry": prix, "sl": sl, "tp1": tp1, "tp2": tp2, "rr": rr, "reason": raison}

    else:
        raison += "\n\n=== AUCUN SETUP ===\nScore insuffisant. Pas de confluence EMA + RSI + Sweep."
        setup = {"signal": "ATTENTE", "entry": prix, "reason": raison}

    setup["buy_score"] = score_a
    setup["sell_score"] = score_v
    setup["trend"] = tendance

    raison += "\n\n=== PLAN D'EXECUTION ==="
    if signal in ("ACHAT", "VENTE"):
        raison += f"\nEntree: {prix:.2f}"
        raison += f"\nSL: {sl:.2f}"
        raison += f"\nTP1: {tp1:.2f} (R:R {rr}:1)"
        raison += f"\nTP2: {tp2:.2f}"
        if signal == "ACHAT":
            raison += f"\nInvalidation: Perte du support {sl:.2f}"
        else:
            raison += f"\nInvalidation: Franchissement de la resistance {sl:.2f}"
    else:
        raison += "\nAucun setup valide"

    setup["reason"] = raison
    return setup
