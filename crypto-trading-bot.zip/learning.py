import re

MODULES = [
    {"id": 0, "title": "Introduction au Trading", "level": 0, "xp": 30,
     "content": "Le trading est l'achat et la vente d'instruments financiers (forex, crypto, actions, indices) dans le but de realiser un profit. Le but est d'acheter bas et vendre haut (ou vendre haut et racheter bas dans le cas d'une vente a decouvert). Un trader analyse les marches en utilisant l'analyse technique (graphiques, indicateurs) et/ou l'analyse fondamentale (economie, news).",
     "quiz": {"q": "Qu'est-ce que le trading ?", "o": ["Acheter et vendre des instruments financiers pour realiser un profit", "Un jeu de hasard", "Investir a long terme uniquement", "Acheter des actions et les garder pour toujours"], "a": 0}},
    {"id": 1, "title": "Structure du Marche", "level": 0, "xp": 40,
     "content": "La structure du marche est la base de l'analyse technique. Les concepts cles sont: \n- HH (Higher High): Sommet plus haut que le precedent\n- HL (Higher Low): Creux plus haut que le precedent (tendance haussiere)\n- LH (Lower High): Sommet plus bas que le precedent\n- LL (Lower Low): Creux plus bas que le precedent (tendance baissiere)\n- MSS (Market Structure Shift): Rupture de structure qui signale un changement de tendance\n- CHOCH (Change of Character): Changement de comportement du prix",
     "quiz": {"q": "Qu'indiquent des HH et HL successifs ?", "o": ["Tendance haussiere", "Tendance baissiere", "Rangement", "Volatilite"], "a": 0}},
    {"id": 2, "title": "Supports et Resistances", "level": 0, "xp": 40,
     "content": "Un support est un niveau de prix ou l'achat est suffisamment fort pour arreter une baisse. Une resistance est un niveau ou la vente est suffisamment forte pour arreter une hausse. Ces niveaux peuvent etre identifies par:\n- Anciens plus hauts et plus bas\n- Niveaux psychologiques (nombres ronds)\n- Zones de congestion\n- EMA (moyennes mobiles)\nLorsque le prix casse un support, il devient resistance. Lorsqu'il casse une resistance, elle devient support.",
     "quiz": {"q": "Que se passe-t-il quand le prix casse une resistance ?", "o": ["Elle devient un support", "Elle reste une resistance", "Elle disparait", "Le marche s'inverse"], "a": 0}},
    {"id": 3, "title": "Order Blocks (OB)", "level": 1, "xp": 50,
     "content": "Un Order Block est une zone de prix ou les institutionnels (banques, fonds) placent leurs ordres importants. C'est la derniere bougie avant un fort mouvement directionnel. Pour identifier un OB haussier: cherchez la derniere bougie baissiere avant un fort mouvement haussier. Pour un OB baissier: cherchez la derniere bougie haussiere avant un fort mouvement baissier. Les OB sont des zones de liquidite ou le prix revient souvent avant de continuer dans sa direction.",
     "quiz": {"q": "Qu'est-ce qu'un Order Block haussier ?", "o": ["La derniere bougie baissiere avant un fort mouvement haussier", "La premiere bougie haussiere", "Un bloc de 10 bougies", "Un indicateur technique"], "a": 0}},
    {"id": 4, "title": "Fair Value Gaps (FVG)", "level": 1, "xp": 50,
     "content": "Un Fair Value Gap (FVG) est un desequilibre de prix cree par 3 bougies consecutives. Il se forme quand la bougie du milieu a une ombre qui ne chevauche pas entierement les bougies adjacentes. Le FVG represente une zone de prix ou peu de transactions ont eu lieu. Le prix revient souvent combler ce gap (rebalance) avant de continuer. Les FVG sont classes en:\n- BULLISH FVG: Bougie haussiere avec gap a la hausse\n- BEARISH FVG: Bougie baissiere avec gap a la baisse",
     "quiz": {"q": "Pourquoi le prix revient-il sur un FVG ?", "o": ["Pour combler le desequilibre et rebalancer le marche", "Par hasard", "A cause des news", "Pour casser des stops"], "a": 0}},
    {"id": 5, "title": "Offre et Demande", "level": 1, "xp": 50,
     "content": "Les zones d'offre et demande sont des niveaux ou le prix a montre un fort rejet. Une zone de demande est une zone ou le prix a rebondi fortement a la hausse (exces d'acheteurs). Une zone d'offre est une zone ou le prix a rebondi fortement a la baisse (exces de vendeurs). La difference avec les Order Blocks: les zones d'offre/demande sont plus larges et basees sur des rallies (mouvements impulsifs) tandis que les OB sont plus precis.",
     "quiz": {"q": "Qu'est-ce qu'une zone de demande ?", "o": ["Une zone ou les acheteurs sont plus forts que les vendeurs", "Une zone ou le prix descend", "Un indicateur", "Un type d'ordre"], "a": 0}},
    {"id": 6, "title": "Fibonacci et OTE", "level": 2, "xp": 60,
     "content": "Fibonacci est un outil mathematique utilise en trading pour identifier les niveaux de retracement et d'extension. Les niveaux cles sont:\n- 0.618 (62%): Premier niveau de retracement important\n- 0.705 (70.5%): Niveau intermediaire\n- 0.79 (79%): Niveau profond\n- -0.27 (127%): Extension pour take profit\n- -0.62 (162%): Extension secondaire\nOTE (Optimal Trade Entry) est la zone entre 62% et 79% de retracement, consideree comme la zone optimale pour entrer dans la direction de la tendance principale. Le niveau 50% sert d'equilibre entre prime et discount.",
     "quiz": {"q": "Quelle est la zone OTE (Optimal Trade Entry) ?", "o": ["Entre 62% et 79% de retracement", "Entre 0% et 50%", "Entre 100% et 200%", "Au-dela de 100%"], "a": 0}},
    {"id": 7, "title": "MSS et CHOCH", "level": 2, "xp": 60,
     "content": "MSS (Market Structure Shift) et CHOCH (Change of Character) sont des signaux de retournement. Un MSS haussier se produit quand le prix casse un sommet apres avoir forme des plus bas ascendants. Un MSS baissier se produit quand le prix casse un creux apres avoir forme des plus hauts descendants. Le CHOCH est un changement plus brutal et definitif de la structure. La confirmation d'un MSS necessite:\n1. Un sweep de liquidite\n2. Un deplacement directionnel\n3. La creation d'un FVG dans la direction du mouvement",
     "quiz": {"q": "Quels sont les 3 elements de confirmation d'un MSS ?", "o": ["Sweep + Deplacement + FVG", "RSI + MACD + EMA", "Volume + Prix + Temps", "Support + Resistance + Tendance"], "a": 0}},
    {"id": 8, "title": "Liquidite et Sweep", "level": 2, "xp": 60,
     "content": "La liquidite en trading ICT represente les zones ou se trouvent les stops des traders. Les deux types principaux:\n- BSL (Buy-side Liquidity): Liquidite au-dessus des plus hauts recents (stops des shorts + limites des longs)\n- SSL (Sell-side Liquidity): Liquidite en-dessous des plus bas recents (stops des longs + limites des shorts)\nLe sweep (ou chasse de liquidite) est un mouvement de prix qui prend ces stops avant de partir dans la direction opposee. Le sweep est le premier element de la sequence MSS.",
     "quiz": {"q": "Ou se trouve la Buy-side Liquidity (BSL) ?", "o": ["Au-dessus des plus hauts recents", "En-dessous des plus bas recents", "Au milieu du range", "Sur l'EMA 200"], "a": 0}},
    {"id": 9, "title": "Killzones ICT", "level": 3, "xp": 70,
     "content": "Les killzones ICT sont des periodes horaires specifiques ou le volume d'echange est le plus eleve et ou les mouvements institutionnels se produisent:\n- Killzone Asiatique: 00:00 - 09:00 UTC\n- Ouverture Londres: 08:00 - 10:00 UTC\n- Fermeture Londres: 12:00 - 14:00 UTC\n- Ouverture New York: 13:00 - 15:00 UTC\n- Fermeture New York: 21:00 - 23:00 UTC\nLes meilleurs setups se produisent generalement pendant les chevauchements de sessions (Londres + NY).",
     "quiz": {"q": "Quelle est la meilleure periode pour trader selon ICT ?", "o": ["Le chevauchement Londres + New York (13h-15h UTC)", "La session asiatique", "Le week-end", "A minuit"], "a": 0}},
    {"id": 10, "title": "Optimal Trade Entry (OTE)", "level": 3, "xp": 70,
     "content": "L'OTE est une combinaison de plusieurs facteurs pour un point d'entree optimal:\n1. Contexte HTF en tendance\n2. Retracement dans la zone Fibonacci 62-79%\n3. Confluence avec Order Block ou FVG\n4. Confirmation MSS sur LTF\n5. Killzone active\nL'OTE maximise le ratio risque/recompense en entrant dans la zone de valeur optimale, avec le stop place derriere le swing de la chasse de liquidite et les take profits aux extensions Fibonacci.",
     "quiz": {"q": "Qu'est-ce que l'OTE combine ?", "o": ["Tendance HTF + Fibonacci 62-79% + OB/FVG + MSS + Killzone", "RSI + MACD + EMA + Bollinger + Volume", "3 indicateurs techniques", "Un seul setup"], "a": 0}},
    {"id": 11, "title": "Gestion de Risque", "level": 3, "xp": 70,
     "content": "La gestion de risque est LE facteur le plus important pour reussir en trading. Regles fondamentales:\n- Ne jamais risquer plus de 1-2% du capital par trade\n- Toujours utiliser un Stop Loss\n- Ratio R:R minimum de 1:2\n- Diversifier ses trades\n- Ne pas sur-trader\n- Tenir un journal de trading\nLe calcul de la taille de position: (Capital x %Risque) / Distance SL = Taille de position",
     "quiz": {"q": "Quel est le risque maximum recommande par trade ?", "o": ["1-2% du capital", "10% du capital", "50% du capital", "Tout le capital"], "a": 0}},
    {"id": 12, "title": "Analyse Multi-Timeframe", "level": 4, "xp": 80,
     "content": "L'analyse multi-timeframe consiste a analyser le meme actif sur differentes periodes pour avoir une vue d'ensemble:\n- HTF (Daily/Weekly): Determine la tendance macro et les zones importantes\n- MTF (4h/1h): Confirme la structure et identifie les setups\n- LTF (15m/5m): Point d'entree precis\nLes timeframes superieurs donnent le contexte, les inferieurs donnent l'execution. La regle: trade dans la direction du HTF, cherche l'entree sur LTF.",
     "quiz": {"q": "Quel timeframe donne le contexte de tendance ?", "o": ["HTF (Daily/Weekly)", "LTF (5m/15m)", "Tous les timeframes", "Aucun"], "a": 0}},
    {"id": 13, "title": "Order Flow Institutionnel", "level": 4, "xp": 80,
     "content": "L'order flow institutionnel est l'etude des flux d'ordres des gros acteurs (banques, fonds, market makers). Concepts:\n- Iceberg Orders: Gros ordres caches divises en petites parties\n- Stop Hunting: Chasse des stops pour creer de la liquidite\n- Absorption: Quand le marche absorbe un gros ordre sans bouger\n- Imbalance: Desequilibre entre acheteurs et vendeurs\nLes institutionnels ne peuvent pas entrer ou sortir d'un coup. Ils creent de la volatilite pour obtenir la meilleure execution.",
     "quiz": {"q": "Pourquoi les institutionnels chassent-ils les stops ?", "o": ["Pour creer de la liquidite et entrer/sortir de leurs positions", "Pour faire perdre les petits traders", "Par hasard", "Pour tester le marche"], "a": 0}},
    {"id": 14, "title": "Systeme de Trading Complet", "level": 4, "xp": 100,
     "content": "Un systeme de trading complet combine tous les concepts appris:\n1. Analyser le HTF pour la tendance\n2. Identifier les zones de liquidite (BSL/SSL)\n3. Attendre un retracement dans la zone EMA\n4. Chercher un sweep + MSS + FVG confluence\n5. Entrer dans la killzone avec OB/FVG dans la zone OTE\n6. Stop derriere le sweep\n7. TP aux extensions Fibonacci (-0.27, -0.62)\n8. Gerer le risque (max 1-2%)\nUn bon systeme doit etre: simple, testable, et repetable.",
     "quiz": {"q": "Quelles sont les qualites d'un bon systeme de trading ?", "o": ["Simple, testable et repetable", "Complexe et mysterieux", "Base sur des intuitions", "Qui change chaque jour"], "a": 0}},
    {"id": 15, "title": "Psychologie du Trading", "level": 5, "xp": 100,
     "content": "La psychologie est la derniere etape vers la maitrise. Les pieges mentaux:\n- FOMO (Fear Of Missing Out): Entrer sur un mouvement deja avance\n- Revenge Trading: Vouloir se refaire apres une perte\n- Sur-confiance: Apres des gains, prendre trop de risques\n- Doute: Ne pas prendre un bon setup par peur\nSolutions:\n- Tenir un journal de trading\n- Suivre son plan a la lettre\n- Accepter les pertes comme faisant partie du jeu\n- Faire des pauses\n- Discipline > Motivation",
     "quiz": {"q": "Comment combattre le FOMO ?", "o": ["Suivre son plan de trading et ne pas entrer sur un mouvement deja avance", "Entrer quand meme au cas ou", "Ignorer le marche", "Augmenter le levier"], "a": 0}},
]

QUESTIONS = {
    "qu est ce que le trading": "Le trading est l'achat et la vente d'instruments financiers (forex, crypto, actions, indices, matieres premieres) dans le but de realiser un profit. On achete un actif a bas prix pour le revendre plus cher (position longue), ou on le vend a decouvert pour le racheter moins cher (position courte).",
    "c est quoi le trading": "Le trading est l'achat et la vente d'instruments financiers (forex, crypto, actions, indices, matieres premieres) dans le but de realiser un profit. On achete un actif a bas prix pour le revendre plus cher (position longue), ou on le vend a decouvert pour le racheter moins cher (position courte).",
    "c est quoi un pip": "Un pip (Point en Pourcentage) est la plus petite unite de variation du prix d'un paire de forex. Pour la plupart des paires (EUR/USD, GBP/USD), 1 pip = 0.0001. Pour les paires avec le Yen (USD/JPY), 1 pip = 0.01. Le pip sert a calculer le gain ou la perte d'un trade.",
    "qu est ce qu un pip": "Un pip (Point en Pourcentage) est la plus petite unite de variation du prix d'un paire de forex. Pour la plupart des paires (EUR/USD, GBP/USD), 1 pip = 0.0001. Pour les paires avec le Yen (USD/JPY), 1 pip = 0.01.",
    "c est quoi le levier": "Le levier est un mecanisme qui permet de trader des positions plus grandes que votre capital. Par exemple, avec un levier de 1:100, vous pouvez controler 100 000$ avec seulement 1000$. Attention: le levier amplifie les gains ET les pertes. Une mauvaise gestion du levier est la cause principale des pertes en trading.",
    "qu est ce que le levier": "Le levier est un mecanisme qui permet de trader des positions plus grandes que votre capital. Par exemple, avec un levier de 1:100, vous pouvez controler 100 000$ avec seulement 1000$.",
    "c est quoi le margin call": "Le margin call (appel de marge) se produit quand votre capital n'est plus suffisant pour couvrir les pertes de vos positions ouvertes. Le broker vous demande soit d'ajouter des fonds, soit de fermer des positions. Si vous ne le faites pas, le broker ferme automatiquement vos positions (stop out).",
    "qu est ce que le margin call": "Le margin call se produit quand votre capital n'est plus suffisant pour couvrir les pertes. Le broker demande plus de fonds ou ferme les positions.",
    "c est quoi un stop loss": "Un Stop Loss (SL) est un ordre automatique qui ferme votre position a un prix predetermine pour limiter vos pertes. C'est l'outil de gestion de risque le plus important. Sans SL, une seule mauvaise operation peut vider votre compte. Placez toujours un SL avant d'entrer dans un trade.",
    "qu est ce qu un stop loss": "Un Stop Loss (SL) ferme automatiquement votre position a un prix predetermine pour limiter les pertes. Outil INDISPENSABLE.",
    "c est quoi un take profit": "Un Take Profit (TP) est un ordre automatique qui ferme votre position quand le prix atteint votre objectif de profit. Il permet de securiser vos gains sans avoir a surveiller le marche en permanence. Le ratio R:R (Risk/Reward) compare la distance au SL et au TP.",
    "c est quoi rsi": "Le RSI (Relative Strength Index) est un indicateur de momentum qui mesure la vitesse et l'amplitude des variations de prix. Il va de 0 a 100. En dessous de 30, l'actif est considere survendu (potentiel achat). Au-dessus de 70, il est surachete (potentielle vente). Dans la strategie EMA + RSI + Sweep, on cherche un RSI < 35 dans une tendance haussiere pour un achat, ou > 65 dans une tendance baissiere pour une vente.",
    "qu est ce que le rsi": "Le RSI mesure le momentum entre 0 et 100. Survendu < 30, surachete > 70. Dans notre strategie: < 35 pour achat en tendance haussiere, > 65 pour vente en tendance baissiere.",
    "c est quoi ema": "L'EMA (Exponential Moving Average) est une moyenne mobile qui donne plus de poids aux prix recents. Contrairement a la SMA (moyenne simple), l'EMA reagit plus rapidement aux changements de prix. Dans notre strategie, on utilise l'EMA 50 et l'EMA 200 sur 1h pour determiner la tendance: prix > EMA 50 > EMA 200 = tendance haussiere, prix < EMA 50 < EMA 200 = tendance baissiere.",
    "qu est ce que ema": "L'EMA est une moyenne mobile exponentielle. EMA 50 et 200 sur 1h determinent la tendance dans notre strategie.",
    "c est quoi un order block": "Un Order Block (OB) est la derniere bougie avant un fort mouvement directionnel. C'est une zone ou les institutionnels ont place des ordres importants. Le prix revient souvent tester cette zone avant de continuer. Un OB haussier est une bougie baissiere juste avant un rallye haussier. Un OB baissier est une bougie haussiere juste avant un effondrement.",
    "qu est ce qu un order block": "L'OB est la derniere bougie avant un fort mouvement. Zone institutionnelle. Prix y revient avant de continuer.",
    "c est quoi un fvg": "Un Fair Value Gap (FVG) est un desequilibre de prix entre 3 bougies consecutives. Il se forme quand le haut d'une bougie ne touche pas le bas de la bougie d'apres (bullish FVG) ou l'inverse (bearish FVG). Le prix revient generalement combler ce gap avant de continuer dans la direction initiale.",
    "qu est ce que fvg": "FVG = desequilibre entre 3 bougies. Gap que le prix revient combler.",
    "c est quoi mss": "Le Market Structure Shift (MSS) est un signal de changement de tendance. Il se compose de 3 etapes: 1) Sweep de liquidite (chasse des stops), 2) Deplacement directionnel fort, 3) Creation d'un FVG dans la direction du mouvement. Un MSS haussier casse un sommet, un MSS baissier casse un creux.",
    "qu est-ce que mss": "MSS = Sweep + Deplacement + FVG. Signale un changement de tendance.",
    "c est quoi la liquidite en trading": "La liquidite en trading ICT represente les zones ou se trouvent les stops des traders. BSL (Buy-side Liquidity) au-dessus des plus hauts. SSL (Sell-side Liquidity) en-dessous des plus bas. Les institutionnels chassent ces stops (sweep) pour creer de la liquidite avant de faire bouger le marche dans la direction opposee.",
    "qu est ce que la liquidite": "Liquidite = zones de stops. BSL en haut, SSL en bas. Les institutionnels les chassent pour entrer/sortir.",
    "c est quoi le sweep": "Le sweep (ou chasse de liquidite) est un mouvement de prix qui prend les stops des traders au-dessus d'un sommet ou en-dessous d'un creux avant de repartir dans la direction opposee. C'est la premiere etape du MSS.",
    "qu est ce que un sweep": "Sweep = chasse des stops. Le prix depasse un sommet/creux pour prendre les stops puis repart en sens inverse.",
    "c est quoi fibonacci": "Fibonacci est un outil qui identifie les niveaux de retracement et d'extension. Niveaux cles: 62%, 70.5%, 79% (retracement/OTE) et -27%, -62% (extensions/TP). La zone OTE (62-79%) est la zone optimale d'entree dans la direction de la tendance.",
    "qu est-ce que fibonacci": "Fibonacci: retracements 62-79% (entree/OTE), extensions -27% et -62% (take profit).",
    "c est quoi l ote": "L'OTE (Optimal Trade Entry) est la zone entre 62% et 79% de retracement Fibonacci. C'est la zone ou le ratio risque/recompense est optimal pour entrer dans la direction de la tendance principale. Combine avec OB/FVG et MSS, c'est le setup le plus fiable.",
    "qu est ce que l ote": "OTE = zone 62-79% Fibonacci, point d'entree optimal combine avec OB/FVG/MSS.",
    "c est quoi les killzones": "Les killzones ICT sont des periodes de forte activite institutionnelle: Asie (00-09h), Londres ouverture (08-10h), Londres fermeture (12-14h), NY ouverture (13-15h), NY fermeture (21-23h). UTC. Les meilleurs trades se font pendant les chevauchements de sessions.",
    "qu est ce que les killzones": "Killzones = periodes de forte activite: Asie, Londres, NY. Chevauchements = meilleurs setups.",
    "comment calculer la taille de position": "Taille position = (Capital x %Risque) / Distance SL. Exemple: 10 000$ x 1% = 100$ de risque. Si SL est a 50 pips, taille = 100/50 = 2$ par pip. Pour le forex, 1 lot standard = 10$/pip, donc 0.2 lots ou 2 mini-lots.",
    "comment gerer son risque": "Regles d'or: 1) Jamais plus de 1-2% risque par trade. 2) Toujours un SL. 3) R:R minimum 1:2. 4) Diversifier. 5) Journal de trading. 6) Pas de revenge trading. 7) Discipline.",
    "c est quoi le r:r": "Le ratio R:R (Risk/Reward) compare le risque potentiel au gain potentiel. R:R 1:2 signifie que vous risquez 1 pour gagner 2. Pour etre profitable en trading, il faut soit un bon R:R, soit un bon taux de reussite, idealement les deux.",
    "qu est ce que le r:r": "R:R = ratio risque/recompense. Minimum 1:2 recommande.",
    "c est quoi un spread": "Le spread est la difference entre le prix d'achat (ask) et le prix de vente (bid). C'est le cout principal du trading (avec les commissions). Plus le spread est bas, meilleur c'est. Les paires majeures (EUR/USD) ont les spreads les plus bas. Les crypto et actions ont des spreads plus larges.",
    "qu est-ce que le spread": "Spread = difference entre ask et bid. Cout principal du trading. Plus bas = mieux.",
    "c est quoi une position longue": "Une position longue (long) est un achat dans l'espoir que le prix monte. On achete bas pour vendre plus haut. 'Going long' signifie qu'on est haussier sur l'actif.",
    "c est quoi une position courte": "Une position courte (short) est une vente a decouvert. On vend d'abord dans l'espoir de racheter plus bas. 'Going short' signifie qu'on est baissier. Attention: le short a un risque illimite en theorie si le prix monte indefiniment.",
    "qu est-ce que le forex": "Le Forex (Foreign Exchange) est le marche des changes, le plus grand marche financier du monde avec +6 000 milliards de $ echanges par jour. On y echange des devises par paires (EUR/USD, GBP/USD, USD/JPY). Le Forex est ouvert 24h/24 du dimanche soir au vendredi soir.",
    "c est quoi le forex": "Forex = marche des changes. Plus grand marche mondial. Paires de devises. Ouvert 24h/5j.",
    "c est quoi la psychologie du trading": "La psychologie est l'aspect mental du trading. Pieges: FOMO (peur de rater), revenge trading (vouloir se refaire), sur-confiance, doute. Solutions: plan de trading, journal, discipline, accepter les pertes. La psychologie est ce qui separe les traders pro des amateurs.",
    "comment devenir un bon trader": "1) Apprends les bases (structure, supports/resistances). 2) Maitrise un seul setup (pas 10). 3) Pape sur un compte demo. 4) Developpe ta gestion de risque. 5) Tiens un journal. 6) Sois discipline. 7) Continue d'apprendre. Le trading est un marathon, pas un sprint.",
    "c est quoi le backtesting": "Le backtesting consiste a tester une strategie sur des donnees historiques pour voir si elle aurait ete rentable. C'est essentiel pour valider un systeme avant de trader en reel. Un bon backtesting doit couvrir plusieurs conditions de marche (tendance, range, volatile).",
    "qu est-ce que le backtesting": "Backtesting = tester une strategie sur des donnees passees pour valider sa rentabilite.",
}

def trouver_reponse(question):
    q = question.lower().strip()
    q = re.sub(r'[^\w\s]', '', q)
    for cle, reponse in QUESTIONS.items():
        mots_cle = cle.split()
        if all(mot in q for mot in mots_cle):
            return reponse
    for cle, reponse in QUESTIONS.items():
        mots_cle = cle.split()
        score = sum(1 for mot in mots_cle if mot in q)
        if score / len(mots_cle) >= 0.6:
            return reponse
    return None

def get_module(mid):
    for m in MODULES:
        if m["id"] == mid:
            return m
    return None

def get_modules_by_level(lvl):
    return [m for m in MODULES if m["level"] <= lvl and not m.get("completed")]

def prochain_module(modules_completes):
    for m in MODULES:
        if m["id"] not in modules_completes:
            return m
    return None

def calculer_niveau(xp):
    if xp < 100: return 0, "Noob"
    if xp < 250: return 1, "Debutant"
    if xp < 500: return 2, "Apprenti"
    if xp < 800: return 3, "Intermediaire"
    if xp < 1200: return 4, "Avance"
    return 5, "Hero"

def total_xp():
    return sum(m["xp"] for m in MODULES)

def barre_progression(xp):
    total = total_xp()
    pct = min(xp / total * 100, 100)
    rempli = int(pct / 5)
    vide = 20 - rempli
    return "[" + "#" * rempli + "-" * vide + f"] {pct:.0f}%"
