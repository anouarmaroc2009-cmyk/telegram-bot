import asyncio
import logging
import os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta

import yfinance as yf
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler
)

from strategies import analyser_marche
from profile import charger_profil, sauvegarder_profil, supprimer_profil, resumer_profil, formater_position, learning_defaut
from learning import MODULES, trouver_reponse, get_module, prochain_module, calculer_niveau, barre_progression, total_xp

load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = int(os.getenv("TELEGRAM_CHAT_ID", "0"))
_grp = os.getenv("GROUP_CHAT_ID")
GROUP_CHAT_ID = int(_grp) if _grp else None

logging.basicConfig(format="%(asctime)s | %(message)s", datefmt="%H:%M:%S", level=logging.INFO)
logger = logging.getLogger("bot")

(NAME_Q, FROM_Q, JOB_Q, PHONE_Q, GMAIL_Q,
 CAPITAL_Q, BROKER_Q, EXPERIENCE_Q, MARKETS_Q, RISK_Q) = range(10)

QUIZ_Q = 99

CATEGORIES = {
    "crypto": ["BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD", "ADA-USD"],
    "forex": ["EURUSD=X", "GBPUSD=X", "USDJPY=X", "USDCAD=X", "AUDUSD=X"],
    "actions": ["AAPL", "TSLA", "AMZN", "GOOGL", "MSFT", "NVDA"],
    "matieres": ["GC=F", "SI=F", "CL=F", "NG=F"],
    "indices": ["^GSPC", "^NDX", "^DJI", "^VIX"],
}

SYMBOL_MAP = {
    "BTC": "BTC-USD", "BITCOIN": "BTC-USD",
    "ETH": "ETH-USD", "ETHEREUM": "ETH-USD",
    "SOL": "SOL-USD", "SOLANA": "SOL-USD",
    "XRP": "XRP-USD", "ADA": "ADA-USD",
    "DOGE": "DOGE-USD", "DOT": "DOT-USD",
    "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X",
    "USDJPY": "USDJPY=X", "USDCAD": "USDCAD=X",
    "AUDUSD": "AUDUSD=X", "NZDUSD": "NZDUSD=X",
    "XAUUSD": "GC=F", "OR": "GC=F",
    "XAGUSD": "SI=F", "ARGENT": "SI=F",
    "SPX": "^GSPC", "SP500": "^GSPC",
    "NDX": "^NDX", "NAS100": "^NDX",
    "DJI": "^DJI", "DOW": "^DJI",
    "VIX": "^VIX",
}

def _est_dst(dt):
    a = dt.year
    mars = datetime(a, 3, 8, tzinfo=timezone.utc)
    nov = datetime(a, 11, 1, tzinfo=timezone.utc)
    debut = mars + timedelta(days=(6 - mars.weekday()))
    fin = nov + timedelta(days=(6 - nov.weekday()))
    return debut <= dt.replace(tzinfo=timezone.utc) < fin

def marche_ouvert(symbole):
    now = datetime.now(timezone.utc)
    wd = now.weekday()
    tm = now.hour * 60 + now.minute
    cat = None
    for c, syms in CATEGORIES.items():
        if symbole in syms:
            cat = c
            break
    if cat == "crypto":
        return True
    if cat == "forex":
        if wd == 5:
            return False
        if wd == 6:
            return tm >= 1320
        if wd == 4:
            return tm < 1320
        return True
    if wd >= 5:
        return False
    dec = -4 if _est_dst(now) else -5
    est = (tm + dec * 60) % 1440
    return 570 <= est <= 960

def normaliser(raw):
    u = raw.upper()
    if u in SYMBOL_MAP:
        return SYMBOL_MAP[u]
    if u.endswith("USDT"):
        return u.replace("USDT", "-USD")
    return u

def telecharger_ohlc(symbole):
    df = yf.download(symbole, period="5d", interval="1h", progress=False)
    if df.empty:
        df = yf.download(symbole, period="3mo", interval="1d", progress=False)
    if df.empty:
        return None
    if hasattr(df.columns, "levels"):
        ouvr, haut, bas, clot = [], [], [], []
        for col in df.columns:
            n = col[0]
            if n == "Open": ouvr = df[col].dropna().tolist()
            elif n == "High": haut = df[col].dropna().tolist()
            elif n == "Low": bas = df[col].dropna().tolist()
            elif n == "Close": clot = df[col].dropna().tolist()
    else:
        ouvr = df["Open"].dropna().tolist()
        haut = df["High"].dropna().tolist()
        bas = df["Low"].dropna().tolist()
        clot = df["Close"].dropna().tolist()
    if not clot or len(clot) < 30:
        return None
    return ouvr, haut, bas, clot

def _p(px):
    if px is None:
        return "N/D"
    if abs(px) < 10:
        return f"{px:.5f}"
    return f"{px:.2f}"

def formater_setup(symbole, s, profil=None):
    if s is None:
        return f"{symbole} : pas de donnees"
    if isinstance(s, str):
        return f"{symbole} : {s}"
    signal = s["signal"]
    if signal in ("ACHAT", "VENTE"):
        tete = f"{symbole} - {signal} | R:R {s['rr']}:1\n"
        tete += f"Entree: ${_p(s['entry'])} | SL: ${_p(s['sl'])} | TP1: ${_p(s['tp1'])} | TP2: ${_p(s['tp2'])}"
        corps = tete + "\n\n" + s["reason"]
        if profil and signal in ("ACHAT", "VENTE"):
            pos = formater_position(symbole, signal, s["entry"], s["sl"], s["tp1"], profil)
            if pos:
                corps += "\n" + pos
        return corps
    return (
        f"{symbole} | {signal}\n"
        f"Prix : ${_p(s.get('entry'))}\n\n"
        f"{s['reason']}"
    )

def analyser_symbole(symbole):
    try:
        ohlc = telecharger_ohlc(symbole)
        if ohlc is None:
            return None
        ouvr, haut, bas, clot = ohlc
        if len(clot) < 30:
            return f"donnees insuffisantes ({len(clot)} bougies)"
        return analyser_marche(ouvr, haut, bas, clot)
    except Exception as e:
        logger.warning(f"analyser_symbole({symbole}) a echoue : {e}")
        return f"erreur : {e}"

async def envoyer_tous(app, texte):
    cibles = [CHAT_ID]
    if GROUP_CHAT_ID:
        cibles.append(GROUP_CHAT_ID)
    for cid in cibles:
        try:
            await app.bot.send_message(chat_id=cid, text=texte)
        except Exception as e:
            logger.error(f"Envoi vers {cid} a echoue : {e}")

async def demarrer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    profil = charger_profil(update.effective_chat.id)
    msg = (
        "Setups Trading EMA 50/200 + RSI + Sweep\n\n"
        "Analyses automatiques toutes les 30 min (marches ouverts uniquement)\n\n"
        "Commandes :\n"
        "/crypto - Bitcoin, ETH, SOL, XRP, ADA\n"
        "/forex - EURUSD, GBPUSD, USDJPY, USDCAD, AUDUSD\n"
        "/actions - AAPL, TSLA, AMZN, GOOGL, MSFT, NVDA\n"
        "/matieres - Or, Argent, Petrole, Gaz\n"
        "/indices - SP500, NDX, DJI, VIX\n"
        "/tout - tous les marches\n"
        "/SYMBOLE - analyse specifique (ex: /btc, /eurusd)\n"
        "/coach - configurer mon profil de risque\n"
        "/profile - voir mon profil\n"
        "/learn - apprendre le trading (0 a hero)\n"
        "/ask <question> - poser une question\n"
        "/quiz - tester tes connaissances\n"
        "/progress - voir ta progression"
    )
    await update.message.reply_text(msg)

async def analyser_categorie(update: Update, context: ContextTypes.DEFAULT_TYPE, symboles):
    cid = update.effective_chat.id
    profil = charger_profil(cid)
    await update.message.reply_text(f"Analyse de {len(symboles)} marches en cours...")
    with ThreadPoolExecutor(max_workers=5) as pool:
        boucle = asyncio.get_running_loop()
        taches = [boucle.run_in_executor(pool, analyser_symbole, sym) for sym in symboles]
        resultats = await asyncio.gather(*taches)
    morceaux = []
    for sym, res in zip(symboles, resultats):
        morceaux.append(formater_setup(sym, res, profil))
    for i in range(0, len(morceaux), 5):
        await context.bot.send_message(chat_id=cid, text="\n\n".join(morceaux[i:i+5]))

async def crypto(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await analyser_categorie(update, context, CATEGORIES["crypto"])

async def forex(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await analyser_categorie(update, context, CATEGORIES["forex"])

async def actions(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await analyser_categorie(update, context, CATEGORIES["actions"])

async def matieres(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await analyser_categorie(update, context, CATEGORIES["matieres"])

async def indices(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await analyser_categorie(update, context, CATEGORIES["indices"])

async def tout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tous = []
    for v in CATEGORIES.values():
        tous.extend(v)
    await analyser_categorie(update, context, tous)

async def gerer_symbole(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = update.message.text.split()
    brut = parts[0][1:] if parts else ""
    if not brut:
        return
    cid = update.effective_chat.id
    profil = charger_profil(cid)
    symbole = normaliser(brut)
    await update.message.reply_text(f"Analyse de {symbole} en cours...")
    boucle = asyncio.get_running_loop()
    with ThreadPoolExecutor(max_workers=1) as pool:
        resultat = await boucle.run_in_executor(pool, analyser_symbole, symbole)
    await update.message.reply_text(formater_setup(symbole, resultat, profil))

async def gerer_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = update.message.text.strip()
    quiz_data = context.user_data.get("quiz_active")
    if quiz_data:
        try:
            choix = int(txt)
            module = quiz_data["module"]
            bonne = module["quiz"]["a"]
            if isinstance(bonne, list):
                bonne = bonne[0]
            profil = charger_profil(update.effective_chat.id)
            ap = profil.get("learning", learning_defaut())
            if choix == bonne:
                ap["xp"] = ap.get("xp", 0) + module["xp"]
                ap["completed_modules"] = list(set(ap["completed_modules"] + [module["id"]]))
                lvl, label = calculer_niveau(ap["xp"])
                await update.message.reply_text(
                    f"Bravo ! Bonne reponse ! +{module['xp']}XP\n"
                    f"Niveau {lvl} ({label}) | XP: {ap['xp']}/{total_xp()}\n\n"
                    f"Prochain: /learn pour continuer"
                )
            else:
                correct = module["quiz"]["o"][bonne]
                await update.message.reply_text(
                    f"Faux. La bonne reponse etait: {correct}\n\n"
                    f"Relis le module avec /learn puis reessaye /quiz"
                )
            profil["learning"] = ap
            sauvegarder_profil(update.effective_chat.id, profil)
        except ValueError:
            await update.message.reply_text("Reponds avec le numero de la bonne reponse (0, 1, 2 ou 3).")
        context.user_data.pop("quiz_active", None)
        return
    await update.message.reply_text(
        "Utilise une commande :\n"
        "/crypto, /forex, /actions, /matieres, /indices, /tout\n"
        "Ou /SYMBOLE (ex: /btc, /eurusd)\n"
        "/coach - profil risque\n"
        "/learn - apprendre le trading\n"
        "/ask <question> - poser une question\n"
        "/quiz - tester tes connaissances\n"
        "/progress - voir ta progression"
    )

async def analyse_auto(app: Application):
    while True:
        try:
            await asyncio.sleep(1800)
            for cat_nom, symboles in CATEGORIES.items():
                ouverts = [s for s in symboles if marche_ouvert(s)]
                if not ouverts:
                    continue
                lignes = [f"-- {cat_nom.upper()} --"]
                boucle = asyncio.get_running_loop()
                with ThreadPoolExecutor(max_workers=5) as pool:
                    resultats = await asyncio.gather(*[boucle.run_in_executor(pool, analyser_symbole, sym) for sym in ouverts])
                for sym, res in zip(ouverts, resultats):
                    lignes.append(formater_setup(sym, res))
                msg = "\n\n".join(lignes)
                if msg.strip():
                    await envoyer_tous(app, msg)
        except Exception as e:
            logger.error(f"Analyse automatique a echoue : {e}")

async def post_init(app: Application):
    asyncio.create_task(analyse_auto(app))

async def erreur(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Erreur avec la mise a jour {update} : {context.error}")

# --- COACHING / ONBOARDING ---

async def coach_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    profil = charger_profil(update.effective_chat.id)
    if profil:
        await update.message.reply_text(
            "Ton profil est deja configure.\n"
            "/profile - voir le profil\n"
            "/reset - recommencer l'onboarding"
        )
        return ConversationHandler.END
    await update.message.reply_text(
        "Je suis ton coach trading et gestionnaire de risque.\n"
        "Reponds a ces 10 questions pour construire ton profil.\n\n"
        "1/10 - Nom: Quel est ton prenom et nom ?"
    )
    return NAME_Q

async def coach_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["name"] = update.message.text.strip()
    await update.message.reply_text(
        "2/10 - Origine: D'ou viens-tu ? (pays, ville)"
    )
    return FROM_Q

async def coach_from(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["location"] = update.message.text.strip()
    await update.message.reply_text(
        "3/10 - Profession: Que fais-tu dans la vie ?"
    )
    return JOB_Q

async def coach_job(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["job"] = update.message.text.strip()
    await update.message.reply_text(
        "4/10 - Telephone: Quel est ton numero de telephone ?"
    )
    return PHONE_Q

async def coach_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["phone"] = update.message.text.strip()
    await update.message.reply_text(
        "5/10 - Email: Quelle est ton adresse Gmail ?"
    )
    return GMAIL_Q

async def coach_gmail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["email"] = update.message.text.strip()
    await update.message.reply_text(
        "6/10 - Capital: Quel est le montant total de ton compte de trading (USD) ?"
    )
    return CAPITAL_Q

async def coach_capital(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        capital = float(update.message.text.replace(",", "").replace(" ", ""))
        if capital <= 0:
            raise ValueError
        context.user_data["capital"] = capital
        await update.message.reply_text(
            "7/10 - Broker: Quel broker utilises-tu et quel est ton levier max ?\n"
            "(ex: IC Markets, 1:100)"
        )
        return BROKER_Q
    except ValueError:
        await update.message.reply_text("Montant invalide. Entre un nombre positif (ex: 10000).")
        return CAPITAL_Q

async def coach_broker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = update.message.text.replace(":", " ").split()
    levier = 100
    broker = update.message.text
    for p in parts:
        try:
            l = int(p)
            if 1 <= l <= 500:
                levier = l
                broker = update.message.text.replace(p, "").replace(":", "").replace("1", "").strip().rstrip(",")
                break
        except ValueError:
            continue
    if not broker:
        broker = update.message.text
    context.user_data["broker"] = broker
    context.user_data["leverage"] = levier
    await update.message.reply_text(
        "8/10 - Experience: Comment evaluerais-tu ton niveau ?\n"
        "debutant / intermediaire / avance"
    )
    return EXPERIENCE_Q

async def coach_experience(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = update.message.text.strip().lower()
    mapping = {"debutant": "debutant", "debut": "debutant", "beginner": "debutant",
               "intermediaire": "intermediaire", "intermediate": "intermediaire", "moyen": "intermediaire",
               "avance": "avance", "advanced": "avance", "expert": "avance"}
    exp = mapping.get(txt)
    if not exp:
        await update.message.reply_text("Choix invalide. Reponds par: debutant, intermediaire ou avance.")
        return EXPERIENCE_Q
    context.user_data["experience"] = exp
    await update.message.reply_text(
        "9/10 - Marches: Quels marches cibles-tu ?\n"
        "(ex: crypto, forex, actions, indices - separes par des virgules)"
    )
    return MARKETS_Q

async def coach_markets(update: Update, context: ContextTypes.DEFAULT_TYPE):
    txt = update.message.text.lower()
    mapping = {"crypto": "crypto", "cryptos": "crypto", "forex": "forex", "fx": "forex",
               "actions": "actions", "stocks": "actions", "equities": "actions",
               "indices": "indices", "index": "indices", "indexes": "indices",
               "matieres": "matieres", "commodities": "matieres", "or": "matieres",
               "gold": "matieres"}
    marches = []
    for mot in txt.replace(",", " ").split():
        normalized = mapping.get(mot.strip())
        if normalized and normalized not in marches:
            marches.append(normalized)
    if not marches:
        await update.message.reply_text("Aucun marche reconnu. Reponds par ex: crypto, forex, actions")
        return MARKETS_Q
    context.user_data["target_markets"] = marches
    await update.message.reply_text(
        "10/10 - Risque: Quel est ton risque prefere par trade ?\n"
        "(0.5%, 1%, ou 2% du capital)"
    )
    return RISK_Q

async def coach_risk(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        txt = update.message.text.replace("%", "").strip()
        risque = float(txt)
        if risque <= 0 or risque > 10:
            raise ValueError
    except ValueError:
        await update.message.reply_text("Invalide. Entre un pourcentage entre 0.5 et 5 (ex: 1).")
        return RISK_Q
    profil = {
        "name": context.user_data.get("name", ""),
        "location": context.user_data.get("location", ""),
        "job": context.user_data.get("job", ""),
        "phone": context.user_data.get("phone", ""),
        "email": context.user_data.get("email", ""),
        "capital": context.user_data["capital"],
        "broker": context.user_data["broker"],
        "leverage": context.user_data["leverage"],
        "experience": context.user_data["experience"],
        "target_markets": context.user_data["target_markets"],
        "risk_percent": risque,
        "learning": learning_defaut()
    }
    sauvegarder_profil(update.effective_chat.id, profil)
    await update.message.reply_text(
        "Profil enregistre ! Voici ton resume :\n\n" + resumer_profil(profil)
    )
    context.user_data.clear()
    return ConversationHandler.END

async def coach_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Onboarding annule.")
    context.user_data.clear()
    return ConversationHandler.END

async def afficher_profil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text(
            "Aucun profil trouve. Utilise /coach pour en creer un."
        )
        return
    await update.message.reply_text(resumer_profil(profil))

async def reset_profil(update: Update, context: ContextTypes.DEFAULT_TYPE):
    supprimer_profil(update.effective_chat.id)
    await update.message.reply_text(
        "Profil supprime. Utilise /coach pour en creer un nouveau."
    )

# --- LEARNING ---

async def apprendre(update: Update, context: ContextTypes.DEFAULT_TYPE):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Configure d abord ton profil avec /coach.")
        return
    ap = profil.get("learning", learning_defaut())
    txt = update.message.text.strip().lower()
    if "list" in txt:
        lignes = ["=== MODULES DISPONIBLES ==="]
        for m in MODULES:
            fait = "OK" if m["id"] in ap.get("completed_modules", []) else " "
            lvl = m["level"]
            label = ["Noob","Deb","App","Int","Avn","Hero"][lvl]
            lignes.append(f"[{fait}] L{lvl}({label}) {m['id']}: {m['title']} ({m['xp']}XP)")
        await update.message.reply_text("\n".join(lignes))
        return
    if "next" in txt:
        suivant = prochain_module(ap.get("completed_modules", []))
        if not suivant:
            lvl, label = calculer_niveau(ap.get("xp", 0))
            await update.message.reply_text(
                f"Bravo ! Tu as complete tous les modules !\n"
                f"Niveau {lvl} ({label}) | XP: {ap['xp']}/{total_xp()}\n"
                f"Tu es un hero du trading !"
            )
            return
        ap["current_module"] = suivant["id"]
        profil["learning"] = ap
        sauvegarder_profil(update.effective_chat.id, profil)
    mod = get_module(ap.get("current_module", 0))
    if not mod:
        mod = MODULES[0]
    fait = mod["id"] in ap.get("completed_modules", [])
    coche = "[OK]" if fait else "[ ]"
    lvl_label = ["Noob","Debutant","Apprenti","Intermediaire","Avance","Hero"][mod["level"]]
    lignes = [
        f"{coche} Module {mod['id']}: {mod['title']}",
        f"Niveau: {mod['level']} ({lvl_label}) | XP: {mod['xp']}",
        "",
        mod["content"],
        "",
        "/quiz - passer le test" if not fait else "/learn next - module suivant",
        "/learn list - voir tous les modules",
    ]
    await update.message.reply_text("\n".join(lignes))

async def poser_question(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("Utilise: /ask <ta question> (ex: /ask c est quoi un order block)")
        return
    question = " ".join(context.args)
    reponse = trouver_reponse(question)
    if reponse:
        await update.message.reply_text(reponse)
    else:
        await update.message.reply_text(
            "Desole, je n ai pas de reponse a cette question. "
            "Essaie de reformuler ou consulte /learn pour apprendre."
        )

async def quiz_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Configure d abord ton profil avec /coach.")
        return
    ap = profil.get("learning", learning_defaut())
    mod = get_module(ap.get("current_module", 0))
    if not mod:
        mod = MODULES[0]
    if mod["id"] in ap.get("completed_modules", []):
        await update.message.reply_text(
            f"Module {mod['id']} deja complete ! Fais /learn next pour le suivant."
        )
        return
    q = mod["quiz"]
    opts = "\n".join(f"{i}) {o}" for i, o in enumerate(q["o"]))
    context.user_data["quiz_active"] = {"module": mod}
    await update.message.reply_text(
        f"Quiz: {mod['title']}\n\n"
        f"{q['q']}\n\n{opts}\n\n"
        f"Reponds avec le numero (0-3)"
    )

async def progression(update: Update, context: ContextTypes.DEFAULT_TYPE):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Configure d abord ton profil avec /coach.")
        return
    ap = profil.get("learning", learning_defaut())
    xp = ap.get("xp", 0)
    lvl, label = calculer_niveau(xp)
    comp = ap.get("completed_modules", [])
    lignes = [
        f"=== PROGRESSION ===",
        f"Niveau {lvl} ({label})",
        f"XP: {xp}/{total_xp()}",
        barre_progression(xp),
        f"",
        f"Modules completes: {len(comp)}/16",
    ]
    for m in MODULES:
        etat = "OK" if m["id"] in comp else str(m["id"])
        lignes.append(f"  [{etat}] {m['title']}")
    lignes.append("")
    lignes.append("/learn pour continuer")
    await update.message.reply_text("\n".join(lignes))

# --- MAIN ---

ONBOARDING_HANDLER = ConversationHandler(
    entry_points=[CommandHandler("coach", coach_start)],
    states={
        NAME_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_name)],
        FROM_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_from)],
        JOB_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_job)],
        PHONE_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_phone)],
        GMAIL_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_gmail)],
        CAPITAL_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_capital)],
        BROKER_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_broker)],
        EXPERIENCE_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_experience)],
        MARKETS_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_markets)],
        RISK_Q: [MessageHandler(filters.TEXT & ~filters.COMMAND, coach_risk)],
    },
    fallbacks=[CommandHandler("annuler", coach_cancel)],
)

def main():
    if not TOKEN or not CHAT_ID:
        logger.error("TELEGRAM_BOT_TOKEN ou TELEGRAM_CHAT_ID manquant dans .env")
        return

    app = Application.builder().token(TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", demarrer))
    app.add_handler(CommandHandler("aide", demarrer))
    app.add_handler(CommandHandler("crypto", crypto))
    app.add_handler(CommandHandler("forex", forex))
    app.add_handler(CommandHandler("actions", actions))
    app.add_handler(CommandHandler("matieres", matieres))
    app.add_handler(CommandHandler("indices", indices))
    app.add_handler(CommandHandler("tout", tout))
    app.add_handler(CommandHandler("scan", tout))
    app.add_handler(CommandHandler("all", tout))
    app.add_handler(CommandHandler("tous", tout))
    app.add_handler(CommandHandler("profile", afficher_profil))
    app.add_handler(CommandHandler("reset", reset_profil))
    app.add_handler(CommandHandler("learn", apprendre))
    app.add_handler(CommandHandler("ask", poser_question))
    app.add_handler(CommandHandler("quiz", quiz_start))
    app.add_handler(CommandHandler("progress", progression))
    app.add_handler(CommandHandler("progression", progression))
    app.add_handler(ONBOARDING_HANDLER)
    app.add_handler(MessageHandler(filters.COMMAND, gerer_symbole))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, gerer_message))
    app.add_error_handler(erreur)

    logger.info("Bot EMA/RSI demarre — coaching risque actif")
    app.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
