import json
import os

FICHIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "profiles.json")

def _charger_tous():
    if not os.path.exists(FICHIER):
        return {}
    try:
        with open(FICHIER, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return {}

def _sauvegarder_tous(data):
    with open(FICHIER, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def charger_profil(chat_id):
    tous = _charger_tous()
    return tous.get(str(chat_id))

def sauvegarder_profil(chat_id, profil):
    tous = _charger_tous()
    tous[str(chat_id)] = profil
    _sauvegarder_tous(tous)

def supprimer_profil(chat_id):
    tous = _charger_tous()
    tous.pop(str(chat_id), None)
    _sauvegarder_tous(tous)

def learning_defaut():
    return {"xp": 0, "completed_modules": [], "current_module": 1}

def resumer_profil(profil):
    lignes = []
    lignes.append("=== PROFIL DE TRADING ===")
    if profil.get("name"):
        lignes.append(f"Nom: {profil['name']}")
    if profil.get("location"):
        lignes.append(f"Origine: {profil['location']}")
    if profil.get("job"):
        lignes.append(f"Profession: {profil['job']}")
    if profil.get("phone"):
        lignes.append(f"Tel: {profil['phone']}")
    if profil.get("email"):
        lignes.append(f"Email: {profil['email']}")
    lignes.append(f"Capital: ${profil['capital']:,.2f}")
    lignes.append(f"Broker: {profil['broker']} | Levier: 1:{profil['leverage']}")
    exp = {"debutant": "Debutant", "intermediaire": "Intermediaire", "avance": "Avance"}
    lignes.append(f"Experience: {exp.get(profil['experience'], profil['experience'])}")
    lignes.append(f"Marches: {', '.join(profil['target_markets'])}")
    lignes.append(f"Risque: {profil['risk_percent']}%/trade")
    risque_cash = profil['capital'] * profil['risk_percent'] / 100
    lignes.append(f"Risque en cash: ${risque_cash:.2f}/trade")
    from learning import calculer_niveau, barre_progression, total_xp
    ap = profil.get("learning", learning_defaut())
    lvl, label = calculer_niveau(ap.get("xp", 0))
    lignes.append("")
    lignes.append(f"Progression: Niveau {lvl} ({label})")
    lignes.append(f"XP: {ap.get('xp', 0)}/{total_xp()}")
    lignes.append(f"Modules: {len(ap.get('completed_modules', []))}/16")
    lignes.append(barre_progression(ap.get("xp", 0)))
    conseil = _conseil_experience(profil)
    lignes.append("")
    lignes.append(f"Avis: {conseil}")
    return "\n".join(lignes)

def _conseil_experience(profil):
    exp = profil.get("experience", "debutant")
    risque = profil["risk_percent"]
    if exp == "debutant":
        if risque > 0.5:
            return "Limite le risque a 0.5% max pour debutant. Execution simple: attendre confluence complete."
        return "Bonne discipline. Continue a attendre tes setups avec confluence complete."
    if exp == "intermediaire":
        if risque > 1.5:
            return "Risque eleve meme pour intermediaire. 1% recommande. Ajoute un filtre macro."
        return "Profile equilibre. Peux commencer a scalper sur 15m en confluence avec HTF."
    if exp == "avance":
        return "Profil avance. Peux utiliser des ordres limites dans la zone EMA pour meilleur R:R."
    return ""

def calculer_taille_position(signal, entry, sl, profil):
    risque_pct = profil["risk_percent"]
    capital = profil["capital"]
    cash_risque = capital * risque_pct / 100
    diff = abs(entry - sl)
    if diff <= 0:
        return None
    taille = cash_risque / diff
    return {"cash_risque": round(cash_risque, 2), "taille": round(taille, 4)}

def formater_position(symbole, signal, entry, sl, tp1, profil):
    pos = calculer_taille_position(signal, entry, sl, profil)
    if pos is None:
        return ""
    lignes = []
    lignes.append(f"")
    lignes.append(f"=== GESTION DE RISQUE ===")
    lignes.append(f"Capital: ${profil['capital']:,.2f} | Risque: {profil['risk_percent']}%")
    lignes.append(f"Cash risque: ${pos['cash_risque']:.2f}")
    if profil.get("target_markets") and any(m in symbole.upper() for m in ["BTC", "ETH", "SOL", "XRP", "ADA", "DOGE"]):
        lignes.append(f"Taille position: {pos['taille']:.4f} {symbole.split('-')[0]}")
        lignes.append(f"Valeur position: ${pos['taille'] * entry:,.2f}")
    else:
        lignes.append(f"Taille position: {pos['taille']:.2f} unites")
        lignes.append(f"Valeur notionnelle: ${pos['taille'] * entry:,.2f}")
    gain_tp1 = abs(tp1 - entry) * pos['taille']
    lignes.append(f"Gain TP1: ${gain_tp1:,.2f} (+{profil['risk_percent'] * 2:.1f}% capital)")
    return "\n".join(lignes)
