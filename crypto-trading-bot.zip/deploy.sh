#!/bin/bash
set -e

echo "=== Deploiement du bot trading ==="

# Config
USER_HOME=$(eval echo ~$SUDO_USER)
BOT_DIR="$USER_HOME/crypto-trading-bot"
BOT_USER="$SUDO_USER"
SERVICE_NAME="crypto-bot"

# Clean install si deja present
if [ -d "$BOT_DIR" ]; then
    echo "Mise a jour du bot existant..."
else
    mkdir -p "$BOT_DIR"
fi

# Copie des fichiers (scp ou git)
# Si tu transferes via SCP:
# scp -r ./* ubuntu@IP:$BOT_DIR/
# 
# Ou avec git:
# git clone https://github.com/tonrepo/crypto-trading-bot.git $BOT_DIR

cd "$BOT_DIR"

# Installation Python
echo "Installation des dependances..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

# Fichier .env
if [ ! -f ".env" ]; then
    echo "Creation du .env..."
    cp .env.example .env
    echo "EDITE .env avec tes infos Telegram : nano .env"
fi

# Service systemd
echo "Installation du service systemd..."
cat > /tmp/$SERVICE_NAME.service << 'SERVICEEOF'
[Unit]
Description=Crypto Trading Bot EMA/RSI/Sweep
After=network.target

[Service]
Type=simple
User=BOT_USER_PLACEHOLDER
WorkingDirectory=BOT_DIR_PLACEHOLDER
ExecStart=BOT_DIR_PLACEHOLDER/venv/bin/python BOT_DIR_PLACEHOLDER/main.py
Restart=always
RestartSec=10
StandardOutput=append:BOT_DIR_PLACEHOLDER/bot.log
StandardError=append:BOT_DIR_PLACEHOLDER/bot.log

[Install]
WantedBy=multi-user.target
SERVICEEOF

sed -i "s|BOT_DIR_PLACEHOLDER|$BOT_DIR|g; s|BOT_USER_PLACEHOLDER|$BOT_USER|g" /tmp/$SERVICE_NAME.service
sudo mv /tmp/$SERVICE_NAME.service /etc/systemd/system/$SERVICE_NAME.service
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME
sudo systemctl start $SERVICE_NAME

echo ""
echo "=== FINI ==="
echo "Status: sudo systemctl status $SERVICE_NAME"
echo "Logs:   sudo journalctl -u $SERVICE_NAME -f"
echo "Config: nano $BOT_DIR/.env"
echo ""
echo "Commandes utiles:"
echo "  sudo systemctl restart $SERVICE_NAME  # redemarrer"
echo "  sudo systemctl stop $SERVICE_NAME     # arreter"
echo "  sudo journalctl -u $SERVICE_NAME -f   # voir les logs en temps reel"
