"""
Deploiement PythonAnywhere (webhook).
1. Uploader tous les fichiers sur PythonAnywhere
2. Creer une Web App → Manual Config → Flask
3. Copier WSGI: from crypto_bot_server import app as application
4. Configurer le webhook depuis la console:
   python -c "import requests; url='https://TON_USER.pythonanywhere.com/webhook'; requests.post('https://api.telegram.org/botTOKEN/setWebhook', json={'url': url})"
"""
import os, sys, json, logging
from flask import Flask, request
from telegram import Update
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    filters, ContextTypes, ConversationHandler
)
from concurrent.futures import ThreadPoolExecutor

# Ajouter le dossier courant au path (necessaire sur PythonAnywhere)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = int(os.getenv("TELEGRAM_CHAT_ID", "0"))
_grp = os.getenv("GROUP_CHAT_ID")
GROUP_CHAT_ID = int(_grp) if _grp else None

from strategies import analyser_marche
from profile import (
    charger_profil, sauvegarder_profil, supprimer_profil,
    resumer_profil, formater_position, learning_defaut
)
from learning import (
    MODULES, trouver_reponse, get_module, prochain_module,
    calculer_niveau, barre_progression, total_xp
)
import yfinance as yf

logging.basicConfig(format="%(asctime)s | %(message)s", datefmt="%H:%M:%S", level=logging.INFO)
logger = logging.getLogger("bot")

CATEGORIES = {
    "crypto": ["BTC-USD", "ETH-USD", "SOL-USD", "XRP-USD", "ADA-USD"],
    "forex": ["EURUSD=X", "GBPUSD=X", "USDJPY=X", "USDCAD=X", "AUDUSD=X"],
    "actions": ["AAPL", "TSLA", "AMZN", "GOOGL", "MSFT", "NVDA"],
    "matieres": ["GC=F", "SI=F", "CL=F", "NG=F"],
    "indices": ["^GSPC", "^NDX", "^DJI", "^VIX"],
}

SYMBOL_MAP = {
    "BTC": "BTC-USD", "BITCOIN": "BTC-USD",
    "ETH": "ETH-USD", "ETHEREUM": "ETH-USD",
    "SOL": "SOL-USD", "SOLANA": "SOL-USD",
    "XRP": "XRP-USD", "ADA": "ADA-USD",
    "DOGE": "DOGE-USD", "DOT": "DOT-USD",
    "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X",
    "USDJPY": "USDJPY=X", "USDCAD": "USDCAD=X",
    "AUDUSD": "AUDUSD=X", "NZDUSD": "NZDUSD=X",
    "XAUUSD": "GC=F", "OR": "GC=F",
    "XAGUSD": "SI=F", "ARGENT": "SI=F",
    "SPX": "^GSPC", "SP500": "^GSPC",
    "NDX": "^NDX", "NAS100": "^NDX",
    "DJI": "^DJI", "DOW": "^DJI",
    "VIX": "^VIX",
}

def _p(px):
    if px is None: return "N/D"
    return f"{px:.5f}" if abs(px) < 10 else f"{px:.2f}"

def formater_setup(symbole, s, profil=None):
    if s is None: return f"{symbole} : pas de donnees"
    if isinstance(s, str): return f"{symbole} : {s}"
    signal = s["signal"]
    if signal in ("ACHAT", "VENTE"):
        tete = f"{symbole} - {signal} | R:R {s['rr']}:1\n"
        tete += f"Entree: ${_p(s['entry'])} | SL: ${_p(s['sl'])} | TP1: ${_p(s['tp1'])} | TP2: ${_p(s['tp2'])}"
        corps = tete + "\n\n" + s["reason"]
        if profil and signal in ("ACHAT", "VENTE"):
            pos = formater_position(symbole, signal, s["entry"], s["sl"], s["tp1"], profil)
            if pos: corps += "\n" + pos
        return corps
    return f"{symbole} | {signal}\nPrix : ${_p(s.get('entry'))}\n\n{s['reason']}"

def analyser_symbole(symbole):
    try:
        df = yf.download(symbole, period="5d", interval="1h", progress=False)
        if df.empty:
            df = yf.download(symbole, period="3mo", interval="1d", progress=False)
        if df.empty: return None
        if hasattr(df.columns, "levels"):
            ouvr, haut, bas, clot = [], [], [], []
            for col in df.columns:
                n = col[0]
                if n == "Open": ouvr = df[col].dropna().tolist()
                elif n == "High": haut = df[col].dropna().tolist()
                elif n == "Low": bas = df[col].dropna().tolist()
                elif n == "Close": clot = df[col].dropna().tolist()
        else:
            ouvr = df["Open"].dropna().tolist()
            haut = df["High"].dropna().tolist()
            bas = df["Low"].dropna().tolist()
            clot = df["Close"].dropna().tolist()
        if not clot or len(clot) < 30: return None
        return analyser_marche(ouvr, haut, bas, clot)
    except Exception as e:
        logger.warning(f"analyser({symbole}) erreur: {e}")
        return f"erreur: {e}"

def normaliser(raw):
    u = raw.upper()
    if u in SYMBOL_MAP: return SYMBOL_MAP[u]
    if u.endswith("USDT"): return u.replace("USDT", "-USD")
    return u

app = Flask(__name__)
ptb_app = None

@ app.route("/webhook", methods=["POST"])
def webhook():
    global ptb_app
    if not ptb_app:
        ptb_app = creer_app()
    try:
        data = request.get_json(force=True)
        update = Update.de_json(data, ptb_app.bot)
        ptb_app.update_queue.put_nowait(update)
        return "OK", 200
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return "OK", 200

@ app.route("/")
def index():
    return "Bot OK !", 200

async def demarrer(update, context):
    await update.message.reply_text(
        "Setups Trading EMA 50/200 + RSI + Sweep\n\n"
        "Commandes:\n/crypto, /forex, /actions, /matieres, /indices, /tout\n"
        "/SYMBOLE (ex: /btc)\n/coach, /profile, /learn, /ask, /quiz, /progress"
    )

async def analyser_categorie(update, context, symboles):
    cid = update.effective_chat.id
    profil = charger_profil(cid)
    await update.message.reply_text(f"Analyse de {len(symboles)} marches...")
    with ThreadPoolExecutor(max_workers=5) as pool:
        boucle = asyncio.get_running_loop()
        taches = [boucle.run_in_executor(pool, analyser_symbole, sym) for sym in symboles]
        resultats = await asyncio.gather(*taches)
    morceaux = []
    for sym, res in zip(symboles, resultats):
        morceaux.append(formater_setup(sym, res, profil))
    for i in range(0, len(morceaux), 5):
        await context.bot.send_message(chat_id=cid, text="\n\n".join(morceaux[i:i+5]))

async def crypto(update, context): await analyser_categorie(update, context, CATEGORIES["crypto"])
async def forex(update, context): await analyser_categorie(update, context, CATEGORIES["forex"])
async def actions(update, context): await analyser_categorie(update, context, CATEGORIES["actions"])
async def matieres(update, context): await analyser_categorie(update, context, CATEGORIES["matieres"])
async def indices(update, context): await analyser_categorie(update, context, CATEGORIES["indices"])
async def tout(update, context):
    tous = []
    for v in CATEGORIES.values(): tous.extend(v)
    await analyser_categorie(update, context, tous)

async def gerer_symbole(update, context):
    parts = update.message.text.split()
    brut = parts[0][1:] if parts else ""
    if not brut: return
    cid = update.effective_chat.id
    profil = charger_profil(cid)
    symbole = normaliser(brut)
    await update.message.reply_text(f"Analyse de {symbole}...")
    boucle = asyncio.get_running_loop()
    with ThreadPoolExecutor(max_workers=1) as pool:
        resultat = await boucle.run_in_executor(pool, analyser_symbole, symbole)
    await update.message.reply_text(formater_setup(symbole, resultat, profil))

async def gerer_message(update, context):
    txt = update.message.text.strip()
    quiz_data = context.user_data.get("quiz_active")
    if quiz_data:
        try:
            choix = int(txt)
            module = quiz_data["module"]
            bonne = module["quiz"]["a"]
            if isinstance(bonne, list): bonne = bonne[0]
            profil = charger_profil(update.effective_chat.id)
            ap = profil.get("learning", learning_defaut())
            if choix == bonne:
                ap["xp"] = ap.get("xp", 0) + module["xp"]
                ap["completed_modules"] = list(set(ap.get("completed_modules", []) + [module["id"]]))
                lvl, label = calculer_niveau(ap["xp"])
                await update.message.reply_text(
                    f"Bravo ! +{module['xp']}XP\nNiveau {lvl} ({label}) | XP: {ap['xp']}/{total_xp()}\n\n/learn pour continuer")
            else:
                correct = module["quiz"]["o"][bonne]
                await update.message.reply_text(f"Faux. La bonne reponse: {correct}\nRelis /learn puis /quiz")
            profil["learning"] = ap
            sauvegarder_profil(update.effective_chat.id, profil)
        except ValueError:
            await update.message.reply_text("Reponds avec 0, 1, 2 ou 3.")
        context.user_data.pop("quiz_active", None)
        return
    await update.message.reply_text("Utilise /crypto, /forex, /actions, /matieres, /indices, /tout ou /SYMBOLE.\n/coach, /profile, /learn, /ask, /quiz, /progress")

# --- Coaching ---
NAME_Q, FROM_Q, JOB_Q, PHONE_Q, GMAIL_Q = range(5)
CAPITAL_Q, BROKER_Q, EXPERIENCE_Q, MARKETS_Q, RISK_Q = range(5, 10)

async def coach_start(update, context):
    if charger_profil(update.effective_chat.id):
        await update.message.reply_text("Profil deja configure. /profile ou /reset")
        return ConversationHandler.END
    await update.message.reply_text("Coach Trading - 10 questions.\n\n1/10 - Nom: Prenom et nom ?")
    return NAME_Q

async def coach_name(update, context):
    context.user_data["name"] = update.message.text.strip()
    await update.message.reply_text("2/10 - Origine: Pays, ville ?")
    return FROM_Q

async def coach_from(update, context):
    context.user_data["location"] = update.message.text.strip()
    await update.message.reply_text("3/10 - Profession ?")
    return JOB_Q

async def coach_job(update, context):
    context.user_data["job"] = update.message.text.strip()
    await update.message.reply_text("4/10 - Telephone ?")
    return PHONE_Q

async def coach_phone(update, context):
    context.user_data["phone"] = update.message.text.strip()
    await update.message.reply_text("5/10 - Email Gmail ?")
    return GMAIL_Q

async def coach_gmail(update, context):
    context.user_data["email"] = update.message.text.strip()
    await update.message.reply_text("6/10 - Capital total du compte (USD) ?")
    return CAPITAL_Q

async def coach_capital(update, context):
    try:
        c = float(update.message.text.replace(",", "").replace(" ", ""))
        if c <= 0: raise ValueError
        context.user_data["capital"] = c
        await update.message.reply_text("7/10 - Broker et levier max ?")
        return BROKER_Q
    except ValueError:
        await update.message.reply_text("Montant invalide.")
        return CAPITAL_Q

async def coach_broker(update, context):
    parts = update.message.text.replace(":", " ").split()
    levier = 100
    broker = update.message.text
    for p in parts:
        try:
            l = int(p)
            if 1 <= l <= 500:
                levier = l
                broker = update.message.text.replace(p, "").replace(":", "").replace("1", "").strip().rstrip(",")
                break
        except ValueError: continue
    context.user_data["broker"] = broker or update.message.text
    context.user_data["leverage"] = levier
    await update.message.reply_text("8/10 - Niveau: debutant / intermediaire / avance")
    return EXPERIENCE_Q

async def coach_experience(update, context):
    txt = update.message.text.strip().lower()
    mapping = {"debutant":"debutant","debut":"debutant","beginner":"debutant",
               "intermediaire":"intermediaire","moyen":"intermediaire",
               "avance":"avance","advanced":"avance","expert":"avance"}
    exp = mapping.get(txt)
    if not exp:
        await update.message.reply_text("debutant / intermediaire / avance")
        return EXPERIENCE_Q
    context.user_data["experience"] = exp
    await update.message.reply_text("9/10 - Marches (crypto, forex, actions, indices) ?")
    return MARKETS_Q

async def coach_markets(update, context):
    txt = update.message.text.lower()
    mapping = {"crypto":"crypto","forex":"forex","fx":"forex",
               "actions":"actions","stocks":"actions",
               "indices":"indices","index":"indices",
               "matieres":"matieres","or":"matieres"}
    marches = []
    for mot in txt.replace(",", " ").split():
        n = mapping.get(mot.strip())
        if n and n not in marches: marches.append(n)
    if not marches:
        await update.message.reply_text("Ex: crypto, forex, actions")
        return MARKETS_Q
    context.user_data["target_markets"] = marches
    await update.message.reply_text("10/10 - Risque par trade ? (0.5%, 1%, 2%)")
    return RISK_Q

async def coach_risk(update, context):
    try:
        risque = float(update.message.text.replace("%", "").strip())
        if risque <= 0 or risque > 10: raise ValueError
    except ValueError:
        await update.message.reply_text("Entre 0.5 et 5.")
        return RISK_Q
    profil = {
        "name": context.user_data.get("name",""),
        "location": context.user_data.get("location",""),
        "job": context.user_data.get("job",""),
        "phone": context.user_data.get("phone",""),
        "email": context.user_data.get("email",""),
        "capital": context.user_data["capital"],
        "broker": context.user_data["broker"],
        "leverage": context.user_data["leverage"],
        "experience": context.user_data["experience"],
        "target_markets": context.user_data["target_markets"],
        "risk_percent": risque,
        "learning": learning_defaut()
    }
    sauvegarder_profil(update.effective_chat.id, profil)
    await update.message.reply_text("Profil enregistre !\n\n" + resumer_profil(profil))
    context.user_data.clear()
    return ConversationHandler.END

async def coach_cancel(update, context):
    await update.message.reply_text("Annule.")
    context.user_data.clear()
    return ConversationHandler.END

async def afficher_profil(update, context):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Aucun profil. /coach")
        return
    await update.message.reply_text(resumer_profil(profil))

async def reset_profil(update, context):
    supprimer_profil(update.effective_chat.id)
    await update.message.reply_text("Profil supprime. /coach pour recreer.")

async def apprendre(update, context):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Configure d abord /coach.")
        return
    ap = profil.get("learning", learning_defaut())
    txt = update.message.text.strip().lower()
    if "list" in txt:
        lignes = ["=== MODULES ==="]
        for m in MODULES:
            f = "OK" if m["id"] in ap.get("completed_modules",[]) else " "
            lignes.append(f"[{f}] L{m['level']} {m['id']}: {m['title']} ({m['xp']}XP)")
        await update.message.reply_text("\n".join(lignes))
        return
    if "next" in txt:
        s = prochain_module(ap.get("completed_modules", []))
        if not s:
            lvl,label = calculer_niveau(ap.get("xp",0))
            await update.message.reply_text(f"Tous completes ! Niveau {lvl} ({label})")
            return
        ap["current_module"] = s["id"]
        profil["learning"] = ap
        sauvegarder_profil(update.effective_chat.id, profil)
    mod = get_module(ap.get("current_module",0)) or MODULES[0]
    fait = mod["id"] in ap.get("completed_modules",[])
    lbl = ["Noob","Debutant","Apprenti","Intermediaire","Avance","Hero"][mod["level"]]
    lignes = [
        f"{'[OK]' if fait else '[ ]'} Module {mod['id']}: {mod['title']}",
        f"Niveau {mod['level']} ({lbl}) | {mod['xp']}XP",
        "", mod["content"], "",
        "/quiz" if not fait else "/learn next",
        "/learn list"
    ]
    await update.message.reply_text("\n".join(lignes))

async def poser_question(update, context):
    if not context.args:
        await update.message.reply_text("/ask <question>")
        return
    r = trouver_reponse(" ".join(context.args))
    await update.message.reply_text(r or "Pas de reponse. Reformule ou /learn.")

async def quiz_start(update, context):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Configure /coach d abord.")
        return
    ap = profil.get("learning", learning_defaut())
    mod = get_module(ap.get("current_module",0)) or MODULES[0]
    if mod["id"] in ap.get("completed_modules",[]):
        await update.message.reply_text(f"Module {mod['id']} deja complete ! /learn next")
        return
    q = mod["quiz"]
    opts = "\n".join(f"{i}) {o}" for i,o in enumerate(q["o"]))
    context.user_data["quiz_active"] = {"module": mod}
    await update.message.reply_text(f"Quiz: {mod['title']}\n\n{q['q']}\n\n{opts}\n\nReponds (0-3)")

async def progression(update, context):
    profil = charger_profil(update.effective_chat.id)
    if not profil:
        await update.message.reply_text("Configure /coach.")
        return
    ap = profil.get("learning", learning_defaut())
    xp = ap.get("xp",0)
    lvl,label = calculer_niveau(xp)
    comp = ap.get("completed_modules",[])
    lignes = [f"=== PROGRESSION ===",f"Niveau {lvl} ({label})",f"XP: {xp}/{total_xp()}",barre_progression(xp),"",f"Modules: {len(comp)}/16"]
    for m in MODULES:
        lignes.append(f"  [{'OK' if m['id'] in comp else m['id']}] {m['title']}")
    lignes.append(""); lignes.append("/learn")
    await update.message.reply_text("\n".join(lignes))

async def erreur(update, context):
    logger.error(f"Erreur: {context.error}")

def creer_app():
    app = Application.builder().token(TOKEN).build()
    for cmd, fn in [
        ("start", demarrer), ("aide", demarrer),
        ("crypto", crypto), ("forex", forex), ("actions", actions),
        ("matieres", matieres), ("indices", indices),
        ("tout", tout), ("scan", tout), ("all", tout), ("tous", tout),
        ("profile", afficher_profil), ("reset", reset_profil),
        ("learn", apprendre), ("ask", poser_question),
        ("quiz", quiz_start), ("progress", progression), ("progression", progression),
    ]:
        app.add_handler(CommandHandler(cmd, fn))
    app.add_handler(ConversationHandler(
        entry_points=[CommandHandler("coach", coach_start)],
        states={
            NAME_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_name)],
            FROM_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_from)],
            JOB_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_job)],
            PHONE_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_phone)],
            GMAIL_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_gmail)],
            CAPITAL_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_capital)],
            BROKER_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_broker)],
            EXPERIENCE_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_experience)],
            MARKETS_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_markets)],
            RISK_Q:[MessageHandler(filters.TEXT&~filters.COMMAND,coach_risk)],
        },
        fallbacks=[CommandHandler("annuler",coach_cancel)],
    ))
    app.add_handler(MessageHandler(filters.COMMAND, gerer_symbole))
    app.add_handler(MessageHandler(filters.TEXT&~filters.COMMAND, gerer_message))
    app.add_error_handler(erreur)
    return app

# Pour PythonAnywhere WSGI: from crypto_bot_server import app
# Pour lancer le webhook manuellement:
# python crypto_bot_server.py set-webhook
if __name__ == "__main__":
    import asyncio
    if len(sys.argv) > 1 and sys.argv[1] == "set-webhook":
        import requests
        url = os.getenv("WEBHOOK_URL")
        if url:
            r = requests.post(f"https://api.telegram.org/bot{TOKEN}/setWebhook", json={"url": url + "/webhook"})
            print(r.json())
        else:
            print("Definir WEBHOOK_URL dans .env")
    else:
        ptb_app = creer_app()
        app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
